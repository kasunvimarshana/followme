<?php

namespace App\Http\Controllers;

use App\EventRecurringPattern;
use Illuminate\Http\Request;

class EventRecurringPatternController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\EventRecurringPattern  $eventRecurringPattern
     * @return \Illuminate\Http\Response
     */
    public function show(EventRecurringPattern $eventRecurringPattern)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\EventRecurringPattern  $eventRecurringPattern
     * @return \Illuminate\Http\Response
     */
    public function edit(EventRecurringPattern $eventRecurringPattern)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\EventRecurringPattern  $eventRecurringPattern
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EventRecurringPattern $eventRecurringPattern)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\EventRecurringPattern  $eventRecurringPattern
     * @return \Illuminate\Http\Response
     */
    public function destroy(EventRecurringPattern $eventRecurringPattern)
    {
        //
    }
}
